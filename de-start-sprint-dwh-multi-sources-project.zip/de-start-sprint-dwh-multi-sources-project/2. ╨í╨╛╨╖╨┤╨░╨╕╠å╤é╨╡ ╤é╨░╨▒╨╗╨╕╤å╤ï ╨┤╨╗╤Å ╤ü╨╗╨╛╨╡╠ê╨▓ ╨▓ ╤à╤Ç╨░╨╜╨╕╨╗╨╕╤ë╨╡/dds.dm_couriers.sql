-- схема DDS (если ещё нет)
CREATE SCHEMA IF NOT EXISTS dds;

-- 2.1. Справочник курьеров
CREATE TABLE IF NOT EXISTS dds.dm_couriers (
    id           INT4 GENERATED ALWAYS AS IDENTITY PRIMARY KEY,  -- surrogate
    courier_id   TEXT     NOT NULL UNIQUE,  -- натуральный ключ из API (/couriers._id)
    courier_name VARCHAR  NOT NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2.2. Факт доставок (по данным API /deliveries)
DROP TABLE IF EXISTS dds.fct_deliveries CASCADE;

CREATE TABLE dds.fct_deliveries (
    id            INT4 GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    delivery_key  TEXT NOT NULL UNIQUE,      -- натуральный ключ из API (delivery_id)
    order_id      TEXT NOT NULL,             -- ВАЖНО: тот же тип, что и dds.dm_orders.id (varchar/text)
    courier_id    INT4 NOT NULL,             -- FK -> dds.dm_couriers.id (surrogate)
    order_ts      TIMESTAMPTZ,
    delivery_ts   TIMESTAMPTZ,
    rate          INT2 CHECK (rate BETWEEN 1 AND 5),
    tip_sum       NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (tip_sum >= 0),
    load_ts       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fct_deliveries_order_fk
      FOREIGN KEY (order_id)  REFERENCES dds.dm_orders(id),

    CONSTRAINT fct_deliveries_courier_fk
      FOREIGN KEY (courier_id) REFERENCES dds.dm_couriers(id)
);

CREATE INDEX IF NOT EXISTS fct_deliveries_order_id_idx   ON dds.fct_deliveries(order_id);
CREATE INDEX IF NOT EXISTS fct_deliveries_courier_id_idx ON dds.fct_deliveries(courier_id);

-- 2.3. Добавить ссылку курьера в заказ (если поля ещё нет)
ALTER TABLE dds.dm_orders
    ADD COLUMN IF NOT EXISTS courier_id INT4;

-- добавить внешний ключ (выполняй один раз; если уже есть — пропусти)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM   information_schema.table_constraints
        WHERE  table_schema = 'dds'
        AND    table_name   = 'dm_orders'
        AND    constraint_name = 'dm_orders_courier_fk'
    ) THEN
        ALTER TABLE dds.dm_orders
            ADD CONSTRAINT dm_orders_courier_fk
            FOREIGN KEY (courier_id) REFERENCES dds.dm_couriers(id);
    END IF;
END$$;

CREATE INDEX IF NOT EXISTS dm_orders_courier_id_idx ON dds.dm_orders(courier_id);
