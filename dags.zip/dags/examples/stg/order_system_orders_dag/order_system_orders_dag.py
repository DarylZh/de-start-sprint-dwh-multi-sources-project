import logging
import pendulum
from airflow.decorators import dag, task
from airflow.models import Variable
from examples.stg.order_system_orders_dag.pg_saver_order import PgSaverOrder
from examples.stg.order_system_orders_dag.order_loader import OrderLoader
from examples.stg.order_system_orders_dag.order_reader import OrderReader
from lib import ConnectionBuilder, MongoConnect

log = logging.getLogger(__name__)

@dag(
    schedule_interval='*/15 * * * *',  # запуск каждые 15 минут
    start_date=pendulum.datetime(2022, 5, 5, tz="UTC"),
    catchup=False,
    tags=['sprint5', 'orders', 'stg'],
    is_paused_upon_creation=False  # DAG сразу активен и виден
)
def sprint5_example_stg_order_system_orders():
    # Подключение к DWH (PostgreSQL)
    dwh_pg_connect = ConnectionBuilder.pg_conn("PG_WAREHOUSE_CONNECTION")

    # Получение переменных окружения из Airflow
    cert_path = Variable.get("MONGO_DB_CERTIFICATE_PATH")
    db_user = Variable.get("MONGO_DB_USER")
    db_pw = Variable.get("MONGO_DB_PASSWORD")
    rs = Variable.get("MONGO_DB_REPLICA_SET")
    db = Variable.get("MONGO_DB_DATABASE_NAME")
    host = Variable.get("MONGO_DB_HOST")

    @task()
    def load_orders():
        # Инициализация компонентов
        pg_saver = PgSaverOrder()
        mongo_connect = MongoConnect(cert_path, db_user, db_pw, host, rs, db, db)  # исправлено db_order -> db_user
        collection_reader = OrderReader(mongo_connect)
        loader = OrderLoader(collection_reader, dwh_pg_connect, pg_saver, log)

        # Запуск загрузки данных
        loader.run_copy()

    order_loader_task = load_orders()  # исправлено load_users() -> load_orders()
    order_loader_task  # type: ignore

order_stg_dag = sprint5_example_stg_order_system_orders()