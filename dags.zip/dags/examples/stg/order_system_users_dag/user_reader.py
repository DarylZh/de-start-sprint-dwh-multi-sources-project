from datetime import datetime
from typing import Dict, List
from lib import MongoConnect

class UserReader:
    def __init__(self, mc: MongoConnect) -> None:
        self.dbs = mc.client()
        # Проверка подключения
        if self.dbs is None:
            raise ValueError("Failed to connect to the MongoDB database.")

    def get_users(self, load_threshold: datetime, limit: int) -> List[Dict]:
        # Формируем фильтр: больше чем дата последней загрузки
        query_filter = {'update_ts': {'$gt': load_threshold}}

        # Формируем сортировку по update_ts. Сортировка обязательна при инкрементальной загрузке.
        sort = [('update_ts', 1)]

        try:
            # Вычитываем документы из MongoDB с применением фильтра и сортировки.
            docs = list(self.dbs.get_collection("users").find(filter=query_filter, sort=sort, limit=limit))
            return docs
        except Exception as e:
            # Логирование ошибки или обработка
            print(f"Error retrieving users from MongoDB: {e}")
            return []  # Возвращаем пустой список в случае ошибки