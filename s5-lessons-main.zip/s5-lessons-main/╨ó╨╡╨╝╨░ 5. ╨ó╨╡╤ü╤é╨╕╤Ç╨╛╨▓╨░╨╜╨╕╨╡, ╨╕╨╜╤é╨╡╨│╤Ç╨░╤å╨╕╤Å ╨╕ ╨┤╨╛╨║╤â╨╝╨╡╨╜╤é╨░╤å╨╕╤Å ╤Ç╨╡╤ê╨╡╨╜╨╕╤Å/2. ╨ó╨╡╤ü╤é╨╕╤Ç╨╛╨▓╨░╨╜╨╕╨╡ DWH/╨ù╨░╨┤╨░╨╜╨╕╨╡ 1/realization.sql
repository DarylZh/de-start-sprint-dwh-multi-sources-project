SELECT 
    'test_01' as test_name,
    COUNT(*) = 0 as test_result,
    NOW() as test_date_time
FROM (
    SELECT 
        COALESCE(actual.restaurant_id, expected.restaurant_id) as restaurant_id,
        COALESCE(actual.settlement_year, expected.settlement_year) as settlement_year,
        COALESCE(actual.settlement_month, expected.settlement_month) as settlement_month,
        CASE 
            WHEN actual.id IS NULL THEN 'Missing in actual'
            WHEN expected.id IS NULL THEN 'Missing in expected'
            ELSE 'Mismatch in data'
        END as discrepancy_type
    FROM public_test.dm_settlement_report_actual actual
    FULL OUTER JOIN public_test.dm_settlement_report_expected expected
        ON actual.restaurant_id = expected.restaurant_id
        AND actual.settlement_year = expected.settlement_year
        AND actual.settlement_month = expected.settlement_month
    WHERE actual.id IS NULL 
        OR expected.id IS NULL
        OR actual.restaurant_name != expected.restaurant_name
        OR actual.orders_count != expected.orders_count
        OR actual.orders_total_sum != expected.orders_total_sum
        OR actual.orders_bonus_payment_sum != expected.orders_bonus_payment_sum
        OR actual.orders_bonus_granted_sum != expected.orders_bonus_granted_sum
        OR actual.order_processing_fee != expected.order_processing_fee
        OR actual.restaurant_reward_sum != expected.restaurant_reward_sum
) discrepancies;