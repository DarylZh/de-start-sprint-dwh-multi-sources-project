UPDATE dds.dm_orders o
SET courier_id = d.courier_id
FROM dds.fct_deliveries d
WHERE d.order_id = o.id
  AND (o.courier_id IS DISTINCT FROM d.courier_id);
