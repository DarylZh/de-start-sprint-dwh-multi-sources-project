-- схема STG
CREATE SCHEMA IF NOT EXISTS stg;

-- курьеры
CREATE TABLE IF NOT EXISTS stg.courier_api_couriers (
  object_id   text PRIMARY KEY,        -- /couriers._id
  object_value jsonb NOT NULL,
  load_ts     timestamptz NOT NULL DEFAULT now()
);

-- рестораны
CREATE TABLE IF NOT EXISTS stg.courier_api_restaurants (
  object_id   text PRIMARY KEY,        -- /restaurants._id
  object_value jsonb NOT NULL,
  load_ts     timestamptz NOT NULL DEFAULT now()
);

-- доставки
CREATE TABLE IF NOT EXISTS stg.courier_api_deliveries (
  delivery_id   text PRIMARY KEY,      -- натуральный ключ из API
  order_id      text NOT NULL,
  courier_id    text NOT NULL,
  restaurant_id text,
  order_ts      timestamptz,
  delivery_ts   timestamptz,
  rate          int2,
  tip_sum       numeric(14,2),
  object_value  jsonb NOT NULL,
  load_ts       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS courier_api_deliveries_order_id_idx   ON stg.courier_api_deliveries(order_id);
CREATE INDEX IF NOT EXISTS courier_api_deliveries_courier_id_idx ON stg.courier_api_deliveries(courier_id);
