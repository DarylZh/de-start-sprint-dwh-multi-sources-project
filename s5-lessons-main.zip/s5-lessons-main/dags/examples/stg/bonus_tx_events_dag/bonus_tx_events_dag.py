import logging
import pendulum
from airflow.decorators import dag, task
from lib import ConnectionBuilder

from examples.stg.bonus_tx_events_dag.bonus_tx_events_loader import (
    StgBonusTxEventsLoader,
)

log = logging.getLogger(__name__)


@dag(
    schedule_interval="*/15 * * * *",
    start_date=pendulum.datetime(2022, 5, 5, tz="UTC"),
    catchup=False,
    tags=["sprint5", "stg", "bonus_tx"],
    is_paused_upon_creation=False,
)
def sprint5_example_stg_bonus_tx_events():
    dwh_pg_connect = ConnectionBuilder.pg_conn("PG_WAREHOUSE_CONNECTION")

    @task(task_id="stg_bonus_tx_events_load")
    def load_bonus_tx_events():
        loader = StgBonusTxEventsLoader(dwh_pg_connect, log)
        loader.run_copy()

    load_bonus_tx_events()


stg_bonus_tx_events_dag = sprint5_example_stg_bonus_tx_events()
