import logging
from typing import Optional

from examples.stg import StgEtlSettingsRepository, EtlSetting
from lib import PgConnect

log = logging.getLogger(__name__)


class StgBonusTxEventsLoader:
    """
    Инкремент: из stg.bonussystem_events (JSON) в плоскую stg.bonus_transaction_events.
    Курсор: last_loaded_id в dds.srv_wf_settings (workflow_key='stg_bonus_tx_events').
    """

    WF_KEY = "stg_bonus_tx_events"
    LAST_LOADED_ID_KEY = "last_loaded_id"
    BATCH_LIMIT = 20000

    def __init__(self, pg: PgConnect, logger: Optional[logging.Logger] = None) -> None:
        self.pg = pg
        self.log = logger or log
        # используем тот же репозиторий настроек — он пишет в dds.srv_wf_settings
        self.settings = StgEtlSettingsRepository()

    def _ensure_table(self, conn) -> None:
        with conn.cursor() as cur:
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS stg.bonus_transaction_events (
                  id            int4           NOT NULL,
                  user_id       int4           NOT NULL,
                  order_id      varchar        NOT NULL,
                  product_id    varchar        NOT NULL,
                  product_price numeric(19,5)  NOT NULL DEFAULT 0,
                  product_count int4           NOT NULL DEFAULT 0,
                  order_ts      timestamp      NOT NULL,
                  order_sum     numeric(19,5)  NOT NULL DEFAULT 0,
                  payment_sum   numeric(19,5)  NOT NULL DEFAULT 0,
                  granted_sum   numeric(19,5)  NOT NULL DEFAULT 0,
                  CONSTRAINT bonus_transaction_events_pk PRIMARY KEY (id, product_id)
                );
                """
            )

    def run_copy(self) -> int:
        with self.pg.connection() as conn:
            self._ensure_table(conn)

            # читаем курсор
            wf = self.settings.get_setting(conn, self.WF_KEY)
            if not wf:
                wf = EtlSetting(
                    id=0,
                    workflow_key=self.WF_KEY,
                    workflow_settings={self.LAST_LOADED_ID_KEY: -1},
                )

            last_loaded_id = int(wf.workflow_settings.get(self.LAST_LOADED_ID_KEY, -1))
            self.log.info(f"[STG bonus_tx] threshold(last_loaded_id)={last_loaded_id}")

            with conn.cursor() as cur:
                cur.execute(
                    """
                    WITH params AS (
                      SELECT %(threshold)s::int AS threshold, %(lim)s::int AS lim
                    ),
                    batch AS (
                      SELECT
                          e.id AS id,
                          (e.event_value::json->>'user_id')::int          AS user_id,
                          e.event_value::json->>'order_id'                AS order_id,
                          pp->>'product_id'                               AS product_id,
                          (pp->>'price')::numeric(19,5)                   AS product_price,
                          (pp->>'quantity')::int                          AS product_count,
                          (e.event_value::json->>'order_date')::timestamp AS order_ts,
                          COALESCE((pp->>'product_cost')::numeric(19,5),
                                   (pp->>'price')::numeric(19,5)*(pp->>'quantity')::int) AS order_sum,
                          (pp->>'bonus_payment')::numeric(19,5)           AS payment_sum,
                          (pp->>'bonus_grant')::numeric(19,5)             AS granted_sum
                      FROM stg.bonussystem_events e
                      CROSS JOIN LATERAL jsonb_array_elements(e.event_value::jsonb->'product_payments') pp
                      , params p
                      WHERE e.event_type='bonus_transaction'
                        AND e.id > p.threshold
                      ORDER BY e.id ASC
                      LIMIT (SELECT lim FROM params)
                    ),
                    upsert AS (
                      INSERT INTO stg.bonus_transaction_events AS s (
                        id, user_id, order_id, product_id, product_price, product_count,
                        order_ts, order_sum, payment_sum, granted_sum
                      )
                      SELECT
                        id, user_id, order_id, product_id, product_price, product_count,
                        order_ts, order_sum, payment_sum, granted_sum
                      FROM batch
                      ON CONFLICT (id, product_id) DO UPDATE
                      SET user_id       = EXCLUDED.user_id,
                          order_id      = EXCLUDED.order_id,
                          product_price = EXCLUDED.product_price,
                          product_count = EXCLUDED.product_count,
                          order_ts      = EXCLUDED.order_ts,
                          order_sum     = EXCLUDED.order_sum,
                          payment_sum   = EXCLUDED.payment_sum,
                          granted_sum   = EXCLUDED.granted_sum
                      RETURNING 1
                    )
                    SELECT COALESCE((SELECT MAX(id) FROM batch), NULL) AS max_id,
                           (SELECT COUNT(*) FROM upsert)                AS upserted;
                    """,
                    {"threshold": last_loaded_id, "lim": self.BATCH_LIMIT},
                )
                max_id, upserted = cur.fetchone()

            if max_id is None:
                self.log.info("[STG bonus_tx] nothing to load.")
                return 0

            # сохраняем курсор
            wf.workflow_settings[self.LAST_LOADED_ID_KEY] = int(max_id)
            self.settings.save_setting(conn, wf.workflow_key, wf.workflow_settings)

            self.log.info(f"[STG bonus_tx] upserted={upserted}, new last_loaded_id={max_id}")
            return upserted
