from datetime import datetime
from typing import Dict, List
from lib import PgConnect  # Импортируем класс для работы с PostgreSQL
import logging

log = logging.getLogger(__name__)

class DmUserReader:  # Исправлено: убран пробел в названии класса
    def __init__(self, pg_connect: PgConnect) -> None:
        self.pg_dest = pg_connect
        # Проверка подключения
        if self.pg_dest is None:
            raise ValueError("Failed to connect to the PostgreSQL database.")

    def get_users(self, load_threshold: datetime, limit: int) -> List[Dict]:
        # Формируем SQL-запрос для выборки пользователей из staging слоя
        query = """
        SELECT user_id, user_name, user_login, update_ts
        FROM stg.users
        WHERE update_ts > %s
        ORDER BY update_ts ASC
        LIMIT %s;
        """
        try:
            with self.pg_dest.connection() as conn:
                cursor = conn.cursor()
                cursor.execute(query, (load_threshold, limit))
                # Извлекаем данные и формируем список словарей
                users = [
                    {
                        "user_id": row[0],
                        "user_name": row[1],
                        "user_login": row[2],
                        "update_ts": row[3]
                    }
                    for row in cursor.fetchall()
                ]
                return users
        except Exception as e:
            log.error(f"Error retrieving users from PostgreSQL: {e}")
            return []  # Возвращаем пустой список в случае ошибки