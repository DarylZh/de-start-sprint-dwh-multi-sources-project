# /lessons/dags/examples/dds/dm_user_dag/dm_user_dag.py

from airflow.decorators import dag, task
import pendulum
from lib import ConnectionBuilder
import logging

# Импортируем все загрузчики из dm_user_loader
from examples.dds.dm_user_dag.dm_user_loader import (
    DmUserLoader,
    DmRestaurantLoader,
    DmTimestampLoader,
    DmProductLoader,
    DmOrderLoader,
    FctProductSalesLoader
)

# Настройка логирования
log = logging.getLogger(__name__)

@dag(
    schedule_interval='@daily',
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    catchup=False,
    tags=['dds', 'fct_product_sales']
)
def load_dm_dag():
    # Создаем подключение к базе данных
    dwh_pg_connect = ConnectionBuilder.pg_conn("PG_WAREHOUSE_CONNECTION")

    @task()
    def check_stg_tables():
        """Проверка наличия данных в stg таблицах"""
        try:
            with dwh_pg_connect.connection() as conn:
                with conn.cursor() as cursor:
                    tables = ['ordersystem_users', 'ordersystem_restaurants', 'ordersystem_orders']
                    for table in tables:
                        cursor.execute(f"SELECT COUNT(*) FROM stg.{table}")
                        count = cursor.fetchone()[0]
                        log.info(f"Table stg.{table} has {count} records")
                        if count == 0:
                            log.warning(f"Table stg.{table} is empty!")
        except Exception as e:
            log.error(f"Error checking stg tables: {e}")

    @task()
    def load_users():
        """Загрузка данных о пользователях"""
        try:
            user_loader = DmUserLoader(dwh_pg_connect, log)
            log.info("Starting to load users")
            user_loader.run_copy()
            log.info("Successfully loaded users")
        except Exception as e:
            log.error(f"Error loading users: {e}")

    @task()
    def load_restaurants():
        """Загрузка данных о ресторанах"""
        try:
            restaurant_loader = DmRestaurantLoader(dwh_pg_connect, log)
            log.info("Starting to load restaurants")
            restaurant_loader.run_copy()
            log.info("Successfully loaded restaurants")
        except Exception as e:
            log.error(f"Error loading restaurants: {e}")

    @task()
    def load_timestamps():
        """Загрузка временных меток"""
        try:
            timestamp_loader = DmTimestampLoader(dwh_pg_connect, log)
            log.info("Starting to load timestamps")
            timestamp_loader.run_copy()
            log.info("Successfully loaded timestamps")
        except Exception as e:
            log.error(f"Error loading timestamps: {e}")

    @task()
    def load_products():
        """Загрузка данных о продуктах"""
        try:
            product_loader = DmProductLoader(dwh_pg_connect, log)
            log.info("Starting to load products")
            product_loader.run_copy()
            log.info("Successfully loaded products")
        except Exception as e:
            log.error(f"Error loading products: {e}")

    @task()
    def load_orders():
        """Загрузка данных о заказах"""
        try:
            order_loader = DmOrderLoader(dwh_pg_connect, log)
            log.info("Starting to load orders")
            order_loader.run_copy()
            log.info("Successfully loaded orders")
        except Exception as e:
            log.error(f"Error loading orders: {e}")

    @task()
    def load_product_sales():
        """Загрузка фактов продаж продуктов"""
        try:
            sales_loader = FctProductSalesLoader(dwh_pg_connect, log)
            log.info("Starting to load product sales")
            sales_loader.run_copy()
            log.info("Successfully loaded product sales")
        except Exception as e:
            log.error(f"Error loading product sales: {e}")

    # Определяем задачи
    check_task = check_stg_tables()
    users_task = load_users()
    restaurants_task = load_restaurants()
    timestamps_task = load_timestamps()
    products_task = load_products()
    orders_task = load_orders()
    product_sales_task = load_product_sales()

    # Устанавливаем правильные зависимости
    check_task >> [users_task, restaurants_task, timestamps_task]
    [users_task, restaurants_task, timestamps_task] >> products_task
    products_task >> orders_task
    orders_task >> product_sales_task

# Инициализация DAG
load_dm = load_dm_dag()
