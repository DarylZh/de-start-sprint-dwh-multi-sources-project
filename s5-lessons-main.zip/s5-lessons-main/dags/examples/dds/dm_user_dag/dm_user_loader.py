from lib import PgConnect
from logging import Logger
import logging

from examples.stg import StgEtlSettingsRepository
from examples.dds import DdsEtlSettingsRepository, EtlSetting as DdsEtlSetting

# ---- USERS / RESTAURANTS / TIMESTAMPS / PRODUCTS / ORDERS без изменений ----
# (оставляю как в твоём файле, только ниже обновляю FctProductSalesLoader и добавляю ClosedBackfill)

class DmUserLoader:
    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger
        self.settings_repository = StgEtlSettingsRepository()

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            self.log.info("Loading users...")
            cursor.execute(
                """
                INSERT INTO dds.dm_users (user_id, user_name, user_login)
                SELECT DISTINCT
                    object_id AS user_id,
                    (object_value::json)->>'name' AS user_name,
                    (object_value::json)->>'login' AS user_login
                FROM stg.ordersystem_users
                WHERE object_id IS NOT NULL
                ON CONFLICT (user_id) DO UPDATE
                SET user_name = EXCLUDED.user_name,
                    user_login = EXCLUDED.user_login;
                """
            )
            self.log.info("Successfully loaded users.")


class DmRestaurantLoader:
    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger
        self.settings_repository = StgEtlSettingsRepository()

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            self.log.info("Loading restaurants...")
            cursor.execute(
                """
                INSERT INTO dds.dm_restaurants (restaurant_id, restaurant_name, active_from, active_to)
                SELECT DISTINCT
                    object_id AS restaurant_id,
                    (object_value::json)->>'name' AS restaurant_name,
                    update_ts AS active_from,
                    '2099-12-31 00:00:00'::timestamp AS active_to
                FROM stg.ordersystem_restaurants
                WHERE object_id IS NOT NULL
                ON CONFLICT (restaurant_id) DO UPDATE
                SET restaurant_name = EXCLUDED.restaurant_name,
                    active_from = EXCLUDED.active_from;
                """
            )
            self.log.info("Successfully loaded restaurants.")


class DmTimestampLoader:
    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger
        self.settings_repository = StgEtlSettingsRepository()

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            self.log.info("Loading timestamps...")
            cursor.execute(
                """
                INSERT INTO dds.dm_timestamps (ts, year, month, day, time, date)
                SELECT DISTINCT
                    (object_value::json->>'date')::timestamp AS ts,
                    EXTRACT(YEAR  FROM (object_value::json->>'date')::timestamp)::int AS year,
                    EXTRACT(MONTH FROM (object_value::json->>'date')::timestamp)::int AS month,
                    EXTRACT(DAY   FROM (object_value::json->>'date')::timestamp)::int AS day,
                    ((object_value::json->>'date')::timestamp)::time AS time,
                    ((object_value::json->>'date')::timestamp)::date AS date
                FROM stg.ordersystem_orders
                WHERE (object_value::json->>'final_status' IN ('CLOSED','CANCELLED'))
                  AND object_value::json->>'date' IS NOT NULL
                ON CONFLICT (ts) DO NOTHING;
                """
            )
            self.log.info("Successfully loaded timestamps.")


class DmProductLoader:
    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger
        self.settings_repository = StgEtlSettingsRepository()

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            self.log.info("Loading products...")
            cursor.execute(
                """
                INSERT INTO dds.dm_products (
                    product_id, product_name, product_price,
                    active_from, active_to, restaurant_id
                )
                SELECT DISTINCT
                    product->>'id' AS product_id,
                    product->>'name' AS product_name,
                    (product->>'price')::numeric(14,2) AS product_price,
                    o.update_ts AS active_from,
                    '2099-12-31 00:00:00'::timestamp AS active_to,
                    r.id AS restaurant_id
                FROM stg.ordersystem_orders o
                JOIN dds.dm_restaurants r
                  ON r.restaurant_id = (o.object_value::jsonb->'restaurant'->>'id')
                CROSS JOIN LATERAL jsonb_array_elements((o.object_value::jsonb)->'order_items') AS product
                WHERE product->>'id' IS NOT NULL
                ON CONFLICT (product_id, restaurant_id, active_to) DO NOTHING;
                """
            )
            self.log.info("Successfully loaded products.")


class DmOrderLoader:
    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger
        self.settings_repository = StgEtlSettingsRepository()

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            self.log.info("Loading orders...")
            cursor.execute(
                """
                INSERT INTO dds.dm_orders (
                    order_key, order_status, restaurant_id, timestamp_id, user_id
                )
                SELECT DISTINCT
                    o.object_value::json->>'_id' AS order_key,
                    o.object_value::json->>'final_status' AS order_status,
                    r.id AS restaurant_id,
                    t.id AS timestamp_id,
                    u.id AS user_id
                FROM stg.ordersystem_orders o
                JOIN dds.dm_timestamps  t ON t.ts = (o.object_value::json->>'date')::timestamp
                JOIN dds.dm_users       u ON u.user_id = (o.object_value::jsonb->'user'->>'id')
                JOIN dds.dm_restaurants r ON r.restaurant_id = (o.object_value::jsonb->'restaurant'->>'id')
                WHERE o.object_value::json->>'final_status' IS NOT NULL
                ON CONFLICT (order_key) DO NOTHING;
                """
            )
            self.log.info("Successfully loaded orders.")


# -----------------  НОВО: факт по событиям бонусной системы  ----------------- #

class FctProductSalesLoader:
    """
    Гружаем факт из stg.bonus_transaction_events:
      - источником служит плоская STG-таблица
      - мэппим на dds.dm_orders и dds.dm_products (версия под ресторан)
      - UPSERT по (order_id, product_id) во факте
      - курсор last_loaded_id хранится в dds.srv_wf_settings (ключ 'fct_product_sales_stg_to_dds_workflow')
    """

    WF_KEY = "fct_product_sales_stg_to_dds_workflow"
    LAST_LOADED_ID_KEY = "last_loaded_id"
    BATCH_LIMIT = 20000

    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger
        self.dds_settings = DdsEtlSettingsRepository()

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            # курсор
            wf = self.dds_settings.get_setting(conn, self.WF_KEY)
            if not wf:
                wf = DdsEtlSetting(
                    id=0,
                    workflow_key=self.WF_KEY,
                    workflow_settings={self.LAST_LOADED_ID_KEY: -1},
                )
            last_loaded_id = int(wf.workflow_settings.get(self.LAST_LOADED_ID_KEY, -1))
            self.log.info(f"[FCT] threshold(last_loaded_id)={last_loaded_id}")

            # берём батч и сразу апсертим во факт
            cursor.execute(
                """
                WITH params AS (
                  SELECT %(threshold)s::int AS threshold, %(lim)s::int AS lim
                ),
                batch AS (
                  SELECT
                      s.id,
                      s.order_id,
                      s.product_id,
                      s.product_count  AS count,
                      s.product_price  AS price,
                      s.order_sum      AS total_sum,
                      s.payment_sum    AS bonus_payment,
                      s.granted_sum    AS bonus_grant
                  FROM stg.bonus_transaction_events s, params p
                  WHERE s.id > p.threshold
                  ORDER BY s.id ASC
                  LIMIT (SELECT lim FROM params)
                ),
                upsert AS (
                  INSERT INTO dds.fct_product_sales (
                      product_id, order_id, count, price, total_sum, bonus_payment, bonus_grant
                  )
                  SELECT
                      p.id AS product_id,
                      o.id AS order_id,
                      b.count, b.price, b.total_sum, b.bonus_payment, b.bonus_grant
                  FROM batch b
                  JOIN dds.dm_orders   o ON o.order_key = b.order_id
                  JOIN dds.dm_products p ON p.product_id    = b.product_id
                                         AND p.restaurant_id = o.restaurant_id
                  ON CONFLICT (product_id, order_id) DO UPDATE
                  SET count         = EXCLUDED.count,
                      price         = EXCLUDED.price,
                      total_sum     = EXCLUDED.total_sum,
                      bonus_payment = EXCLUDED.bonus_payment,
                      bonus_grant   = EXCLUDED.bonus_grant
                  RETURNING 1
                )
                SELECT COALESCE((SELECT MAX(id) FROM batch), NULL) AS max_id,
                       (SELECT COUNT(*) FROM upsert)               AS upserted;
                """,
                {"threshold": last_loaded_id, "lim": self.BATCH_LIMIT},
            )
            max_id, upserted = cursor.fetchone()
            if max_id is None:
                self.log.info("[FCT] nothing to load.")
                return 0

            # обновляем курсор
            wf.workflow_settings[self.LAST_LOADED_ID_KEY] = int(max_id)
            self.dds_settings.save_setting(conn, wf.workflow_key, wf.workflow_settings)

            self.log.info(f"[FCT] upserted={upserted}, new last_loaded_id={max_id}")
            return upserted


class FctProductSalesClosedBackfillLoader:
    """
    Добивка позиций CLOSED БЕЗ событий (bonus=0) за «вчера-UTC».
    Нужна, чтобы количество строк сошлось с тестом.
    """

    def __init__(self, pg_dest: PgConnect, logger: Logger) -> None:
        self.pg_dest = pg_dest
        self.log = logger

    def run_copy(self):
        with self.pg_dest.connection() as conn, conn.cursor() as cursor:
            self.log.info("[FCT backfill] inserting CLOSED items without events for yesterday-UTC...")
            cursor.execute(
                """
                WITH w AS (
                  SELECT (now() AT TIME ZONE 'utc')::date - 2 AS d1,
                         (now() AT TIME ZONE 'utc')::date - 1 AS d2
                ),
                closed_items AS (
                  SELECT
                      so.object_value::json->>'_id' AS order_key,
                      oi->>'id'                     AS product_src_id,
                      (oi->>'quantity')::int        AS qty,
                      (oi->>'price')::numeric(19,5) AS price,
                      ((oi->>'quantity')::int * (oi->>'price')::numeric(19,5))::numeric(19,5) AS total_sum
                  FROM stg.ordersystem_orders so
                  CROSS JOIN LATERAL jsonb_array_elements(so.object_value::jsonb->'order_items') AS oi
                  WHERE (so.object_value::json->>'final_status')='CLOSED'
                    AND ((so.object_value::json->>'date')::timestamp)::date
                        BETWEEN (SELECT d1 FROM w) AND (SELECT d2 FROM w)
                ),
                missing AS (
                  SELECT
                      ci.order_key,
                      ci.product_src_id
                  FROM closed_items ci
                  JOIN dds.dm_orders o
                       ON o.order_key = ci.order_key
                  JOIN dds.dm_products p
                       ON p.product_id    = ci.product_src_id
                      AND p.restaurant_id = o.restaurant_id
                  LEFT JOIN dds.fct_product_sales pr
                       ON pr.order_id   = o.id
                      AND pr.product_id = p.id
                  WHERE pr.order_id IS NULL
                )
                INSERT INTO dds.fct_product_sales (
                  product_id, order_id, count, price, total_sum, bonus_payment, bonus_grant
                )
                SELECT
                  p.id, o.id,
                  ci.qty, ci.price, ci.total_sum,
                  0::numeric(19,5), 0::numeric(19,5)
                FROM missing m
                JOIN closed_items   ci ON ci.order_key = m.order_key AND ci.product_src_id = m.product_src_id
                JOIN dds.dm_orders  o  ON o.order_key = m.order_key
                JOIN dds.dm_products p  ON p.product_id = m.product_src_id AND p.restaurant_id = o.restaurant_id
                ON CONFLICT (product_id, order_id) DO NOTHING;
                """
            )
            self.log.info("[FCT backfill] done.")
