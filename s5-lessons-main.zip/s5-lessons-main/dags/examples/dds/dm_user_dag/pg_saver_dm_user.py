from datetime import datetime
from typing import Any
from lib.dict_util import json2str
from psycopg import Connection

class PgSaverDmUser :

    def save_object(self, conn: Connection, user_id: str, update_ts: datetime, val: Any):
        # Преобразуем данные в строку JSON
        str_val = json2str(val)  # Это значение не используется в SQL, возможно, его стоит убрать
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO dds.dm_users (user_id, user_name, user_login, update_ts)
                VALUES (%(user_id)s, %(user_name)s, %(user_login)s, %(update_ts)s)
                ON CONFLICT (user_id) DO UPDATE
                SET
                    user_name = EXCLUDED.user_name,
                    user_login = EXCLUDED.user_login,
                    update_ts = EXCLUDED.update_ts;
                """,
                {
                    "user_id": user_id,
                    "user_name": val.get("user_name"),  # Используем get для безопасного доступа
                    "user_login": val.get("user_login"),  # Используем get для безопасного доступа
                    "update_ts": update_ts
                }
            )
