WITH src AS (
  SELECT
    d.delivery_id,
    d.order_id,
    d.courier_id,
    d.order_ts,
    d.delivery_ts,
    d.rate,
    COALESCE(d.tip_sum,0) AS tip_sum
  FROM stg.courier_api_deliveries d
)
INSERT INTO dds.fct_deliveries (
  delivery_key, order_id, courier_id, order_ts, delivery_ts, rate, tip_sum
)
SELECT
  s.delivery_id,
  o.id             AS order_id,
  c.id             AS courier_id,
  s.order_ts,
  s.delivery_ts,
  s.rate,
  s.tip_sum
FROM src s
JOIN dds.dm_orders   o ON o.order_key   = s.order_id
JOIN dds.dm_couriers c ON c.courier_id  = s.courier_id
ON CONFLICT (delivery_key) DO UPDATE
SET order_id    = EXCLUDED.order_id,
    courier_id  = EXCLUDED.courier_id,
    order_ts    = EXCLUDED.order_ts,
    delivery_ts = EXCLUDED.delivery_ts,
    rate        = EXCLUDED.rate,
    tip_sum     = EXCLUDED.tip_sum;
