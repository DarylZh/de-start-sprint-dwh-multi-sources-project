-- схема CDM (если ещё нет)
CREATE SCHEMA IF NOT EXISTS cdm;

-- витрина выплат курьерам
CREATE TABLE IF NOT EXISTS cdm.dm_courier_ledger (
    id                    INT4 GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    courier_id            INT4       NOT NULL,  -- FK -> dds.dm_couriers.id (surrogate)
    courier_name          VARCHAR    NOT NULL,
    settlement_year       INT2       NOT NULL,
    settlement_month      INT2       NOT NULL,
    orders_count          INT4       NOT NULL CHECK (orders_count >= 0),
    orders_total_sum      NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (orders_total_sum >= 0),
    rate_avg              NUMERIC(3,2)  NOT NULL DEFAULT 0 CHECK (rate_avg >= 0 AND rate_avg <= 5),
    order_processing_fee  NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (order_processing_fee >= 0),
    courier_order_sum     NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (courier_order_sum >= 0),
    courier_tips_sum      NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (courier_tips_sum >= 0),
    courier_reward_sum    NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (courier_reward_sum >= 0),

    CONSTRAINT dm_courier_ledger_uk
      UNIQUE (courier_id, settlement_year, settlement_month),

    CONSTRAINT dm_courier_ledger_month_ck
      CHECK (settlement_month BETWEEN 1 AND 12),

    CONSTRAINT dm_courier_ledger_year_ck
      CHECK (settlement_year >= 2022 AND settlement_year < 2500)
);

